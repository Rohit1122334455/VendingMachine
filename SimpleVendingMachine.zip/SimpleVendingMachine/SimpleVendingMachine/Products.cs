﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleVendingMachine
{
    class Products
    {
        // Get the Product and Dispatch
        public string DisplayProductSelection()
        {
            Console.WriteLine("Select one Product from below: ");
            Console.WriteLine(" Cola  ");
            Console.WriteLine(" Chips ");
            Console.WriteLine(" Candy ");
            Console.WriteLine();
            Console.WriteLine("Please Make your Selection : ");
            return MakeProductSelection(Convert.ToString(Console.ReadLine().ToUpper()));

        }

        private string MakeProductSelection(string selection)
        {
            string selected = selection;
            bool SelectedOk = false;
            while (!SelectedOk)
            {
                switch (selection)
                {
                    case Constants.cola:
                        selected = Constants.cola;
                        SelectedOk = true;
                        break;
                    case Constants.chips:
                        selected = Constants.chips;
                        SelectedOk = true;
                        break;
                    case Constants.candy:
                        selected = Constants.candy;
                        SelectedOk = true;
                        break;
                    default:
                        Console.WriteLine("Invalid Selection. Please select from Above List : ");
                        selection = Convert.ToString(Console.ReadLine().ToUpper());
                        selected = selection;
                        SelectedOk = false;
                        break;

                }
                
           
            
            }

            return selected;
        }

        public bool GetProduct(String product, Double amount)
        {

            if (product != null && product != "")
            {
                if (product.ToUpper() == Constants.cola)
                {
                    if (amount == Constants.colaPrice)
                    {
                        Console.WriteLine("Thank you!");
                        return true;
                    }

                    else if (amount < Constants.colaPrice)
                    {
                        Console.WriteLine("Price of the item is " + Constants.colaPrice.ToString() + " Inserted amount is " + amount);
                        Console.WriteLine("Please insert sufficent amount");
                        return false;
                    }
                }

                else if (product.ToUpper() == Constants.chips)
                {
                    if (amount == Constants.chipsPrice)
                    {
                        Console.WriteLine("Thank you!");
                        return true;
                    }

                    else if (amount < Constants.chipsPrice)
                    {
                        Console.WriteLine("Price of the item is " + Constants.chipsPrice.ToString() + " Inserted amount is " + amount);
                        Console.WriteLine("Please insert sufficent amount");
                        return false;
                    }
                }

                else if (product.ToUpper() == Constants.candy)
                {
                    if (amount == Constants.candyPrice)
                    {
                        Console.WriteLine("Thank you!");
                        return true;
                    }

                    else if (amount < Constants.candyPrice)
                    {
                        Console.WriteLine("Price of the item is " + Constants.candyPrice.ToString() + " Inserted amount is " + amount);
                        Console.WriteLine("Please insert sufficent amount");
                        return false;
                    }
                }

                else
                {
                    Console.WriteLine("Product is not available");
                    return false;
                }

            }

            return true;
        }



    }
}
