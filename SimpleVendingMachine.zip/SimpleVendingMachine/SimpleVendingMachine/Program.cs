﻿using System;

namespace SimpleVendingMachine
{
    class Program
    {
        static void Main(string[] args)
        {


            Products products = new Products();

            string productsSelected = products.DisplayProductSelection();

            string CoinType = "";
            double totalAmount = 0;
            string coinReturn = "";
            bool check = false;
            while (!check)
            {
                Console.WriteLine("Please Insert Coin :");
                Console.WriteLine("Coin Weight : ");
                int coinWeight = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Coin Size : ");
                int coinSize = Convert.ToInt32(Console.ReadLine());

                Denominations denominations = new Denominations();
                CoinType = denominations.Depositedcoin(coinWeight, coinSize);

                double coinValue = 0;

                switch (CoinType)
                {
                    case Constants.nickel:
                        coinValue = Constants.nickelValue;
                        break;
                    case Constants.dime:
                        coinValue = Constants.dimeValue;
                        break;
                    case Constants.quater:
                        coinValue = Constants.quaterValue;
                        break;
                    case Constants.penny:
                        coinValue = Constants.pennyValue;
                        break;

                    default:
                        coinValue = 0;
                        break;
                }

                if (coinValue == 0)
                {
                    Console.WriteLine("Please Insert a Valid Coin : ");
                    check = false;
                    CoinType = Convert.ToString(Console.ReadLine());
                }
                else if (coinValue == 0.01)
                {
                    Console.WriteLine("Penny's are not allowed, Please collect your penny and insert a valid coin: ");
                    coinReturn += CoinType;
                    check = false;
                    break;
                }
                else
                {
                    totalAmount = totalAmount + coinValue;
                    
                }
                if (totalAmount > 0)
                {
                    if (products.GetProduct(productsSelected, totalAmount))
                    {
                        check = true;
                        break;
                    }
                }

            }
            Console.ReadLine();


        }
    }
}
