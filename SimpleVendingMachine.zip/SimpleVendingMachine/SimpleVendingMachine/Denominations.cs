﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleVendingMachine
{
    class Denominations
    {
        public string Depositedcoin(int coinWeight, int coinSize)
        {
            string coinType = "";
            if(coinWeight >0 && coinSize> 0)
            {
                if(coinWeight == Constants.nickelWight && coinSize == Constants.nickelSize)
                {
                    coinType = Constants.nickel;
                }
                else if (coinWeight == Constants.dimeWight && coinSize == Constants.dimeSize)
                {
                    coinType = Constants.dime;
                }
                else if (coinWeight == Constants.quaterWight && coinSize == Constants.quaterSize)
                {
                    coinType = Constants.quater;
                }
                else if (coinWeight == Constants.pennyWight && coinSize == Constants.pennySize)
                {
                    coinType = Constants.penny;
                }
                else
                {
                    coinType = "";
                }
            }
            return coinType;
        }
    }
}
