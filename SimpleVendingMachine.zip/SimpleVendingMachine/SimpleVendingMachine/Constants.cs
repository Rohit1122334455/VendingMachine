﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleVendingMachine
{
    public static class Constants
    {
        //Constants Valuesare stored here

        //Nickle Constants
        public const int nickelWight = 4;
        public const int nickelSize = 15;
        public const double nickelValue = 0.05;

        // dime Constants
        public const int dimeWight = 5;
        public const int dimeSize = 10;
        public const double dimeValue = 0.10;

        // Quater Constants
        public const int quaterWight = 3;
        public const int quaterSize = 5;
        public const double quaterValue = 0.25;

        // penny Constants
        public const int pennyWight = 1;
        public const int pennySize = 1;
        public const double pennyValue = 0.01;

        //Demoniations names
        public const string nickel = "NICKEL";
        public const string dime = "DIME";
        public const string quater = "QUATER";
        public const string penny = "PENNY";

        //Products
        
        public const string cola = "COLA";
        public const string chips = "CHIPS";
        public const string candy = "CANDY";

        // Amount of the Products
        public const double colaPrice = 1.00;
        public const double chipsPrice = 0.50;
        public const double candyPrice = 0.65;
              


    }
}
